import { configureStore } from "@reduxjs/toolkit"
import { rootReducer } from "./rootReducer"
// import materialUIReducer from '../index'

const store = configureStore({
    reducer :{
        root: rootReducer,
        // materialUI: materialUIReducer,
    }
})

export default store