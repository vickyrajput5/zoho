import React from 'react'
import { useDispatch } from 'react-redux';

export const ProDropdown = () => {
    const dispatch = useDispatch();
  return (
    <div>
        <button onClick={() => dispatch({ type: "logout" })}>Sign Out</button>
    </div>
  )
}
