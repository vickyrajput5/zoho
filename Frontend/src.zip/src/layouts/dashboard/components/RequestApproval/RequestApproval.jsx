import React from "react";

export const RequestAprroval = () => {
  return (
    <div>
      <h4>Request For Approval</h4>
    </div>
  );
};
