import { Box } from "@mui/material";
import Grid from "@mui/material/Grid";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";

function Birthday() {
  return (
    <Box>
      <Grid>
        <h4>Birthday</h4>
      </Grid>
    </Box>
  );
}

export default Birthday;
