import React from "react";

export const Favorites = () => {
  return (
    <div>
      <h4>Favorites</h4>
    </div>
  );
};
