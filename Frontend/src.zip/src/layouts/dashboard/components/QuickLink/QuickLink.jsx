import React from "react";

export const QuickLink = () => {
  return (
    <div>
      <h4>QuickyLink</h4>
    </div>
  );
};
