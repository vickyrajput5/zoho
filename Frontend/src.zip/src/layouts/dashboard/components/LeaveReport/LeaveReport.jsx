import React from "react";

export const LeaveReport = () => {
  return (
    <div>
      <h4>Leave Report</h4>
    </div>
  );
};
