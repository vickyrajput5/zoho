import React from "react";

export const NewHire = () => {
  return (
    <div>
      <h4>New Hire</h4>
    </div>
  );
};
