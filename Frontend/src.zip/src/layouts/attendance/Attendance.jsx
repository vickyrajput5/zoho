import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import React from "react";

export const Attendance = () => {
  return (
    <DashboardLayout>
      <DashboardNavbar />
      <h1>Attendance</h1>
    </DashboardLayout>
  );
};
